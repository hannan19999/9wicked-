This is a WIP (Work in Progress). 
I am currently working on revamping the entire addon. 
Meaning changes to existing code (like the luas being together again), 
removing code and adding new features. 
This does not have all options finished yet, so dont expect perfection.