##These files are copyright 2013-2014 Arctium Project.

##Website -- https://arctium.org/

##Source -- https://github.com/Arctium/Arctium-Tools

##Instructions.
+ 1 - Compile source in release with Visual Studio C# 2013
+ 2 - Drag your wow.exe and wow-64.exe to the patcher icon to patch.
+ 3 - Don't ask for support because your not going to get any!