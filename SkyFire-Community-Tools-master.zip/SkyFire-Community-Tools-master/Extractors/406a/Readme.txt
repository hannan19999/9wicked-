For proper extraction please read this. http://wiki.projectskyfire.org/index.php?title=Installation_Extract_Mmaps

FYI the 32 bit extractor will work on a 64 bit system.